-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 10, 2020 at 11:07 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trip2morocco`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `prenom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numéro_de_télé` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ville` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adresse` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code_postal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mot_de_passe` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sexe` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirmation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirme_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `prenom`, `nom`, `numéro_de_télé`, `ville`, `adresse`, `code_postal`, `email`, `mot_de_passe`, `sexe`, `confirmation`, `confirme_date`) VALUES
(1, 'Test', 'account', '1640262468', 'oujda', 'adresse', '164929', 'testaccount@gmail.com', '$2y$10$WCP8vMTrauudb.LlmSPq/ee7k5SEK0q2.Gs6f3V71YQ7RRtVy8/Ji', 'male', 'OUI', '2020-06-09 00:00:00'),
(12, 'chi khona', 'chi wahd', '061640262', 'tétouan', 'adresse', '60000', 'khona@gmail.fr', '$2y$10$/hNKp9otAlhb0.6x9lymU.dAdhrU.gH/rTA0QBEq2zuECxp8mRtZG', 'male', 'OUI', '2020-06-09 00:00:00'),
(13, 'said', 'mechkuri', '0621548975', 'marrakech', 'adresse...', '12000', 'said@gmail.com', '$2y$10$6nskuHuqAIiIEOu3e7jdL.NjsKHx9R2v1BA52PdoRaPYgox8/V1jW', 'male', 'OUI', '2020-06-09 00:00:00'),
(20, 'prenom', 'nom', '+212 123456789', 'marrakech', '5555 une adresse', '60000', 'u3301886@gmail.com', '$2y$10$RPSPL3QKveSbCo.EpRewr.Fs03N5d1AiOa70/N3wzB5d1SPlyD5Ea', 'male', 'NON', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
CREATE TABLE IF NOT EXISTS `reservation` (
  `id_reservation` int(11) NOT NULL AUTO_INCREMENT,
  `prenom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numéro_tele` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ville` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Nombre_Personne` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `trip_en_famille` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `equipements` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `assistant` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `destination` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Date_debut` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Date_fin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_client` int(11) DEFAULT NULL,
  `is_client` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_reservation`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id_reservation`, `prenom`, `nom`, `email`, `numéro_tele`, `ville`, `Nombre_Personne`, `trip_en_famille`, `equipements`, `assistant`, `destination`, `Date_debut`, `Date_fin`, `id_client`, `is_client`) VALUES
(1, 'test', 'tests', 'aserty@gmail.com', '55', 'el jadida', '1', 'non', 'Sans', 'non', 'Cascade', '15/3/2021', '2020-06-24', NULL, 'NON'),
(2, 'Test', 'account', 'testaccount@gmail.com', '1640262468', 'azilal', '4', 'oui', 'Sans', 'non', 'Cascade', '15/3/2021', '2020-06-25', 1, 'OUI'),
(8, 'ikram', 'merk', 'ikram@gmail.com', '05246825825', 'marrakech', '4', 'oui', 'Avec', 'non', 'Cascade', '15/3/2021', '2020-06-10', NULL, 'NON'),
(7, 'said', 'mechkuri', 'said@gmail.com', '0621548975', 'marrakech', '6', 'oui', 'Avec', 'non', 'Vallée', '6/6/2021', '2020-06-30', 13, 'OUI'),
(15, 'said', 'mechkuri', 'contact@gmail.com', '+212 123456789', 'default', '1', 'oui', 'Avec', 'oui', 'Cascade', '15/3/2021', '15/02/2000', NULL, 'NON'),
(18, 'Test', 'account', 'testaccount@gmail.com', '1640262468', 'tanger', '4', 'oui', 'Avec', 'non', 'Montagne', '15/3/2021', '15/02/2000', 1, 'OUI');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
